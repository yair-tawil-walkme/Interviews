export interface Row {
  id: number
  name: string
  email: string
  age: number
}
